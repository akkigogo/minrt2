#pragma once

float myfadd(float, float);
float myfsub(float, float);
float myfmul(float, float);
float myfdiv(float, float);
float myfsqrt(float);
int myftoi(float);
float myitof(int);
int myfless(float, float);
int myfeq(float, float);
float myfloor(float);